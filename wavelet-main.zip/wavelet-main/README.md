To run the server:
```bash
javac Server.java Program.java
java Main [port]
//e.g: java Main 8080
```

“`wavelet`” – noun; a small wave of water; a ripple (Oxford Dictionary). A cute name for a little web server from UCSD (Joe)
